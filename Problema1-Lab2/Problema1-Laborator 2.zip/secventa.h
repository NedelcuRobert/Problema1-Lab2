#include <string>
#include <iostream>

using namespace std;

void citire_secventa_siruri(string secventa[], int dim);
void apartenenta_sir_secventa(string secventa[], string sir,int dim);